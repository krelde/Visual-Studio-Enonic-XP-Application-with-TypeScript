﻿declare module "xp/i18n" {
    var exp: lib.xp.i18n;
    export = exp;
}
