﻿declare module "xp/node" {
    var exp: lib.xp.node;
    export = exp;
}
