﻿interface IComponentBase {
    name: string; 
    path: string; 
    type: string;
    description: string; 
    config: any;
    regions: any;
}