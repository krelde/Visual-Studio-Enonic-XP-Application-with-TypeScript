﻿declare module "xp/repo" {
    var exp: lib.xp.repo;
    export = exp;
}
