'use strict';
import { ControllerWithRegions } from '../controller';

export abstract class PageController extends ControllerWithRegions {
}
