﻿declare module "xp/thymeleaf" {
    var exp: lib.xp.thymeleaf;
    export = exp;
}
