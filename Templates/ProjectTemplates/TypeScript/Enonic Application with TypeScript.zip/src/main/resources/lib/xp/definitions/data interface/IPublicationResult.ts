﻿interface IPublicationResult {
    pushedContents: Array<string>;
    deletedContents: Array<string>;
    failedContents: Array<string>;
}


