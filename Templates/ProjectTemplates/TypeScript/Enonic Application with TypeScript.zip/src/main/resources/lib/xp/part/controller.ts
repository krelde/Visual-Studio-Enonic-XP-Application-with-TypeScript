'use strict';
import { Controller } from '../controller';

export abstract class PartController extends Controller {
}
