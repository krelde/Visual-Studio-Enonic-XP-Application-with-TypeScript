﻿declare module "xp/value" {
    var exp: lib.xp.value;
    export = exp;
}
