﻿interface IAuthenticationResult {
    authenticated: boolean;
    user: IPrincipalBase;
}