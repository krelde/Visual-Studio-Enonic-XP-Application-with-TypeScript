﻿declare module "xp/http-client" {
    var exp: lib.xp.httpclient;
    export = exp;
}
