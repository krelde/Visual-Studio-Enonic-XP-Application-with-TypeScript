﻿interface ICallback {
    ():void;
}