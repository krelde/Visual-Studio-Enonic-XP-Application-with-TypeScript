﻿declare module "xp/io" {
    var exp: lib.xp.io;
    export = exp;
}
