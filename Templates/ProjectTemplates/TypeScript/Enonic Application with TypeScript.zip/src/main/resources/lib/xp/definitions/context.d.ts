﻿declare module "xp/context" {
    var exp: lib.xp.context;
    export = exp;
}
