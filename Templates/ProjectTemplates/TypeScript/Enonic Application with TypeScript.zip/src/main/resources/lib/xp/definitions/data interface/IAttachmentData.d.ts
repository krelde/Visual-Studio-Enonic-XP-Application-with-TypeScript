﻿interface IAttachmentData {
    name: string;
    label: string;
    size: number;
    mimeTyoe: string;
}