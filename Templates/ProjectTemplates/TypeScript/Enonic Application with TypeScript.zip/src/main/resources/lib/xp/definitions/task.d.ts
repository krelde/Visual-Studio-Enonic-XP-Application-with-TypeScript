﻿declare module "xp/task" {
    var exp: lib.xp.task;
    export = exp;
}
