﻿declare module "xp/mustache" {
    var exp: lib.xp.mustache;
    export = exp;
}
