﻿declare module "xp/event" {
    var exp: lib.xp.event;
    export = exp;
}
