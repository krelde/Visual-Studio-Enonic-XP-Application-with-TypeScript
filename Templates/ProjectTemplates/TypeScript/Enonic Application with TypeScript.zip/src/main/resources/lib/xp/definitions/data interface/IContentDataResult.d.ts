﻿interface IContentDataResult {
    total: number;
    count: number;
    hits: Array<IContentDataBase>;
}