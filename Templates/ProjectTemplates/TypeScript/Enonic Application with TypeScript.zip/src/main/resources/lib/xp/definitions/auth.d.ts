﻿declare module "xp/auth" {
    var exp: lib.xp.auth;
    export = exp;
}
