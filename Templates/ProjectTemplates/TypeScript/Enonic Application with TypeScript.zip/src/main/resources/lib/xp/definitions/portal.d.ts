﻿declare module "xp/portal" {
    var exp: lib.xp.portal;
    export = exp;
}

