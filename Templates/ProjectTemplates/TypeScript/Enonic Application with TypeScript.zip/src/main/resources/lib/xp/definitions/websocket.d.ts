﻿declare module "xp/websocket" {
    var exp: lib.xp.websocket;
    export = exp;
}
