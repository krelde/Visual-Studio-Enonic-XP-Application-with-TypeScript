﻿interface IPrincipalsResult {
    total: number;
    count: number;
    hits: Array<IPrincipalBase>;
}