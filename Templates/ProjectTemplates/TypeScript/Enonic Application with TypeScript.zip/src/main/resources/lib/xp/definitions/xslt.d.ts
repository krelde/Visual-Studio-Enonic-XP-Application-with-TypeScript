﻿declare module "xp/xslt" {
    var exp: lib.xp.xslt;
    export = exp;
}
