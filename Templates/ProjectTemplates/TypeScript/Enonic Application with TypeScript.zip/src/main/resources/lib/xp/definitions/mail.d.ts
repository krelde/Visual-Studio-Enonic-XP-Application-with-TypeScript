﻿declare module "xp/mail" {
    var exp: lib.xp.mail;
    export = exp;
}

