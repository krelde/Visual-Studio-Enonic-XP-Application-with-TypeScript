﻿declare module "xp/cahce" {
    var exp: lib.xp.cahce;
    export = exp;
}
