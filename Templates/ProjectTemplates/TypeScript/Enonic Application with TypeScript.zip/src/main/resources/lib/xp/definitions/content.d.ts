﻿declare module "xp/content" {
    var exp: lib.xp.content;
    export = exp;
}

